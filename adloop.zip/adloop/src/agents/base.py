"""Shared LLM-calling logic for every agent in the team."""
import time
from .. import config


class BaseAgent:
    """
    Retries with exponential backoff on transient API errors, and falls back
    to a mock response when config.MOCK_MODE is on (or no API key is configured).
    """

    def __init__(self, name: str, system_prompt: str, max_retries: int = 3):
        self.name = name
        self.system_prompt = system_prompt
        self.max_retries = max_retries

    def _call_llm(self, user_message: str) -> str:
        if config.MOCK_MODE:
            return self._mock_response(user_message)

        last_error = None
        for attempt in range(1, self.max_retries + 1):
            try:
                response = config.client.messages.create(
                    model=config.MODEL,
                    max_tokens=1024,
                    system=self.system_prompt,
                    messages=[{"role": "user", "content": user_message}],
                )
                return response.content[0].text
            except Exception as e:
                last_error = e
                wait = 2 ** attempt
                print(f"[{self.name}] API error (attempt {attempt}/{self.max_retries}): {e}. "
                      f"Retrying in {wait}s...")
                time.sleep(wait)

        # Every retry failed — fail loudly rather than silently returning bad data.
        raise RuntimeError(f"{self.name} failed after {self.max_retries} attempts: {last_error}")

    def _mock_response(self, user_message: str) -> str:
        return "[MOCK OUTPUT]"

    def run(self, *args, **kwargs):
        raise NotImplementedError("Each agent must implement its own run().")
